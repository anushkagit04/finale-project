from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')  # This is your "Start" page

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')  # Your dashboard page

@app.route('/maintainance')
def maintenance():
    return render_template('maintainance.html')  # Your maintenance page

if __name__ == '__main__':
    app.run(debug=True)
