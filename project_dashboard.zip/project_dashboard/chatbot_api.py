def apnabot(prompt):
    import google.generativeai as genai

    genai.configure(api_key="AIzaSyDmW0k6J9iZGNUlg-ioYx6zIfbfGoccDUM")
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)
    return response.text